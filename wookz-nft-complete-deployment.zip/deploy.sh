#!/bin/bash

# Wookz.NFT Deployment Script
echo "🚀 Starting Wookz.NFT deployment..."

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Docker if not installed
if ! command -v docker &> /dev/null; then
    echo "🐳 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
fi

# Install Docker Compose if not installed
if ! command -v docker-compose &> /dev/null; then
    echo "🔧 Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# Start Docker service
echo "🔄 Starting Docker service..."
systemctl start docker
systemctl enable docker

# Navigate to website directory
cd /root/wookz-nft

# Stop any existing containers
echo "🛑 Stopping existing containers..."
docker-compose down

# Build and start the website
echo "🏗️ Building and starting website..."
docker-compose up -d --build

# Wait a moment for containers to start
sleep 10

# Check if containers are running
echo "✅ Checking deployment status..."
docker-compose ps

# Show logs
echo "📋 Recent logs:"
docker-compose logs --tail=20

echo "🎉 Deployment complete!"
echo "🌐 Your website should be available at:"
echo "   - http://$(curl -s ifconfig.me)"
echo "   - http://wookzman.com (once DNS is configured)"
