# 🚀 Wookz.NFT Deployment Instructions

## Prerequisites
- DigitalOcean account with a droplet
- Domain wookzman.com pointing to your droplet
- SSH access to your droplet

## Step 1: Access Your DigitalOcean Droplet

1. **Log into DigitalOcean** at https://cloud.digitalocean.com
2. **Go to Droplets** in the left sidebar
3. **Click on your droplet** (or create a new one if needed)
4. **Copy the IP address** of your droplet
5. **Open terminal/command prompt** and connect via SSH:
   ```bash
   ssh root@YOUR_DROPLET_IP
   ```

## Step 2: Install Required Software

Once connected to your droplet, run these commands:

```bash
# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Install Git (if not already installed)
apt install git -y
```

## Step 3: Upload Your Website Files

### Option A: Using SCP (Recommended)
From your local computer, run:
```bash
scp -r C:\Users\eluna\Desktop\wookz.nft\* root@YOUR_DROPLET_IP:/root/wookz-nft/
```

### Option B: Using Git (Alternative)
1. Create a GitHub repository
2. Upload your files to GitHub
3. On your droplet, run:
```bash
git clone https://github.com/yourusername/wookz-nft.git
cd wookz-nft
```

## Step 4: Deploy the Website

On your droplet, run:

```bash
# Navigate to your website directory
cd /root/wookz-nft

# Make sure Docker is running
systemctl start docker
systemctl enable docker

# Build and start the website
docker-compose up -d --build

# Check if it's running
docker-compose ps
```

## Step 5: Configure Your Domain

1. **In DigitalOcean DNS settings:**
   - Go to Networking > Domains
   - Add domain: wookzman.com
   - Create A record: @ → YOUR_DROPLET_IP
   - Create A record: www → YOUR_DROPLET_IP

2. **Test your website:**
   - Visit http://YOUR_DROPLET_IP (should show your website)
   - Visit http://wookzman.com (should show your website)

## Step 6: Set Up SSL Certificate (Optional but Recommended)

```bash
# Install Certbot
apt install certbot python3-certbot-nginx -y

# Get SSL certificate
certbot --nginx -d wookzman.com -d www.wookzman.com
```

## Troubleshooting

### Check if website is running:
```bash
docker-compose ps
docker-compose logs
```

### Restart website:
```bash
docker-compose down
docker-compose up -d --build
```

### Check nginx status:
```bash
docker exec -it wookz-nft_wookz-nft_1 nginx -t
```

## Important Files
- `index.html` - Main website file
- `assets/` - All CSS, JS, and images
- `Dockerfile` - Container configuration
- `docker-compose.yml` - Deployment configuration
- `nginx.conf` - Web server configuration

## Support
If you need help, check:
1. Docker logs: `docker-compose logs`
2. Nginx logs: `docker exec -it wookz-nft_wookz-nft_1 tail -f /var/log/nginx/access.log`
3. System logs: `journalctl -u docker`
